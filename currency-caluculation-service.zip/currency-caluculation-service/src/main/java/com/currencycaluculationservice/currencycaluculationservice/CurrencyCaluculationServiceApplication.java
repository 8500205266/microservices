package com.currencycaluculationservice.currencycaluculationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyCaluculationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyCaluculationServiceApplication.class, args);
	}

}
